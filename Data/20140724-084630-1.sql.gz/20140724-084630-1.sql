-- -----------------------------
-- Think MySQL Data Transfer 
-- 
-- Host     : 127.0.0.1
-- Port     : 3306
-- Database : test
-- 
-- Part : #1
-- Date : 2014-07-24 08:46:30
-- -----------------------------

SET FOREIGN_KEY_CHECKS = 0;


-- -----------------------------
-- Table structure for `my_access`
-- -----------------------------
DROP TABLE IF EXISTS `my_access`;
CREATE TABLE `my_access` (
  `role_id` smallint(6) unsigned NOT NULL,
  `node_id` smallint(6) unsigned NOT NULL,
  `level` tinyint(1) NOT NULL,
  `module` varchar(50) DEFAULT NULL,
  KEY `groupId` (`role_id`),
  KEY `nodeId` (`node_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `my_article`
-- -----------------------------
DROP TABLE IF EXISTS `my_article`;
CREATE TABLE `my_article` (
  `article_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tid` int(10) unsigned NOT NULL,
  `title` varchar(40) NOT NULL,
  `keyword` varchar(255) NOT NULL,
  `pubtime` int(10) unsigned NOT NULL,
  `summary` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `approval` int(10) unsigned NOT NULL,
  `opposition` int(10) unsigned NOT NULL,
  `iscommend` tinyint(1) unsigned NOT NULL,
  `ispush` tinyint(1) unsigned NOT NULL,
  `isslides` tinyint(1) unsigned NOT NULL,
  `islock` tinyint(1) unsigned NOT NULL,
  `dtims` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`article_id`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `my_article`
-- -----------------------------
INSERT INTO `my_article` VALUES ('2', '62', 'dsadsadsad', 'dsadsadsadsa', '1405932174', 'dsadsadsadsa', 'sfsgfddgdgf<img src=\"./Uploads/Article/day_140721/201407212253293656.jpg\" alt=\"\" />dsadsaddsadsadsadsdsadsadsa															', '0', '0', '1', '1', '1', '0', '0');
INSERT INTO `my_article` VALUES ('3', '62', 'dsadsadsadsad', 'sdsadssa', '1405953860', 'sdadsadsadsadaddsadsadsadsadas', '<p><img src=\"./Uploads/Article/day_140721/201407212254446508.jpg\" alt=\"\" /><img src=\"./Uploads/Article/day_140721/201407212243267860.jpg\" alt=\"\" /></p><p><br /></p>					', '0', '0', '1', '1', '1', '0', '0');
INSERT INTO `my_article` VALUES ('4', '64', 'dsadsa', 'dsdsassd', '1405953966', 'dsasdsa', '<p>sdsadsadsadsadsadsadsa</p><p><br /></p><p><br /></p><p><br /></p><p><img src=\"./Uploads/Article/day_140721/201407212245485281.jpg\" alt=\"\" /></p>', '16', '1', '1', '1', '1', '0', '0');
INSERT INTO `my_article` VALUES ('5', '65', 'cxzcxz', 'cxzcxz', '1405955076', 'cxzcxz', 'cxzcxzxxsadaaaaaaaaaaaaaaaaaaaa', '71', '7', '1', '1', '1', '0', '0');
INSERT INTO `my_article` VALUES ('6', '63', 'dsadsa', 'dsadsadsa', '1406102997', 'dsadsadsa', 'dsadsadsadsa					', '45', '10', '1', '1', '1', '0', '0');
INSERT INTO `my_article` VALUES ('7', '64', ' 而使', ' 而使 而使 而使', '1406124761', ' 而使 而使 而使 而使', '<div class=\"col-1\"><div class=\"article\"><h1 class=\"article-title\">六一儿童节快乐之童年的游戏！</h1><p class=\"info\"><a href=\"http://weibo.com/u/3283500720/home?wvr=5&amp;lf=reg\" target=\"_blank\" class=\"author\">sunshine</a>&nbsp;·&nbsp;<span class=\"launch-time\">2014/06/01 10:16</span>&nbsp;·&nbsp;<span class=\"cmt-count\">3</span>条评论</p><p></p><p>&nbsp; 早就沉寂在了记忆深处的六一汇演，超市货柜上久没光顾的AD钙奶，日渐变多的生活烦恼，童年似乎真的已经离我们很远了，当我们唱着“当初的愿望实现了吗”的时候，我们甚至已经开始缅怀青春，可是童年的欢乐无论怎样都是无可抹去的，今天，小坊就和大家一起温习一下我们小时候玩的游戏，童年在游戏里永存~</p><p><img src=\"/resource/kindeditor-4.1.7/attached/image/20140601/20140601094839_27567.jpg\" width=\"330\" height=\"220\" align=\"left\" alt=\"\" /> </p><p>&nbsp; &nbsp;4399。说起童年就不得不谈到4399上的小游戏，无论是男孩子们热衷的格斗游戏还是女娃娃们超级喜欢的女生小游戏，4399已经强势地占据了我们童年的一部分（其实小坊现在还是会上去玩。。） 戳这里重品童年的味道:<a href=\"http://www.4399.com/\" target=\"_blank\">http://www.4399.com/</a> </p><p><br /></p><p><img src=\"/resource/kindeditor-4.1.7/attached/image/20140601/20140601095015_63458.jpg\" width=\"330\" height=\"258\" align=\"left\" alt=\"\" /> </p><p>&nbsp;超级玛丽。超级玛丽作为上世纪超级经典的游戏，相信大家小时候或多或少都有玩过，简单易上手，关卡丰富多样，具有很强的可玩性，据说flappybird的终极BOSS就是马里奥，由此就可知道这个可爱的“小红帽”有多深入人心了~ 超级玛丽的传送门：<a href=\"http://app.hustonline.net/software/detail/339\" target=\"_blank\">点我哦</a> </p><p><br /></p><p><img src=\"/resource/kindeditor-4.1.7/attached/image/20140601/20140601095653_54900.jpg\" width=\"330\" height=\"224\" align=\"left\" alt=\"\" /> </p><p><br /></p><p>拳皇。拳皇不用多说，就算是长大了这个游戏还是很多人心中的挚爱，现在的拳皇也有手机版哟，我是传送门：<a href=\"http://as.baidu.com/a/item?docid=6481386&amp;pre=web_am_se&amp;f=web_alad_2_2@next\" target=\"_blank\">拳皇97手机版</a> </p><p><br /></p><p><br /></p><p><br /></p><p><img src=\"/resource/kindeditor-4.1.7/attached/image/20140601/20140601100620_66202.jpg\" width=\"330\" height=\"246\" align=\"left\" alt=\"\" /> </p><p>野菜部落。野菜部落的画面清新、造型可爱，在2006年的时候曾经风靡全国各地，是很多人记忆中无法抹去的一部分，野菜部落在2010年关闭，但是一直有真爱粉们试图让它重生，现在他们已经还原了野菜部落的一个基本版，如果你也是野菜部落曾经的玩家，戳这里重温当年的回忆吧：<a href=\"http://pan.baidu.com/s/1jGuW9gi\" target=\"_blank\">空雅哦</a> </p><p><br /></p><p><img src=\"/resource/kindeditor-4.1.7/attached/image/20140601/20140601100141_68208.jpg\" width=\"330\" height=\"248\" align=\"left\" alt=\"\" /> </p><p>&nbsp;Chuzzle。毛毛球，超Q三消游戏，分为经典模式、竞速模式和解密模式，里面的毛毛们都非常可爱！会随着书包的移动与点击做出不同的反映，但是游戏虽然可爱，通关可不容易哦，30分钟免费版：<a href=\"http://pan.baidu.com/s/1qWjVa8k\" target=\"_blank\">真的超Q哦</a>&nbsp;<a href=\"http://app.hustonline.net/software/detail/292\" target=\"_blank\">这是Mac版哦</a> </p><p><br /></p><p><span style=\"line-height:1.5;\">&nbsp;</span> </p><p><span style=\"line-height:1.5;\"><br /></span> </p><p><span style=\"line-height:1.5;\">&nbsp;童年除了这些电脑游戏，更多的其实还是跳皮筋、躲猫猫等，我们不再是儿童，可是我们都有一颗童心呢~</span> </p><p>&nbsp; 小坊祝大家儿童节快乐！~\\(≧▽≦)/~</p><p></p></div><div class=\"cmt-wrapper\"><form action=\"/comment/add_article_cmt/98\" method=\"post\" id=\"form-launch-cmt\" class=\"clr\"><h2 title=\"我来评论\" class=\"elements txt-hide title\">我来评论</h2><textarea name=\"ipt-cmt\" id=\"ipt-cmt\" class=\"ipt\" cols=\"30\" rows=\"5\" maxlength=\"140\" requeried=\"\"></textarea><div class=\"ipt-wrapper usr-name\"><label for=\"ipt-usr-name\">留下大名</label><input type=\"text\" id=\"ipt-usr-name\" name=\"ipt-usr-name\" class=\"ipt\" maxlength=\"12\" requeried=\"\" value=\"\" /></div><!-- 验证码 --><div class=\"ipt-wrapper captcha\"><label for=\"ipt-captcha\">验证码</label><input type=\"text\" id=\"ipt-captcha\" name=\"ipt-captcha\" class=\"ipt\" minlength=\"4\" maxlength=\"4\" required=\"\" /><span id=\"captcha-img\" title=\"点击刷新验证码\" src=\"http://localhost/\"><img src=\"http://202.114.18.13:1025/1406098801.1165.jpg\" width=\"80\" height=\"30\" style=\"border:0;\" alt=\" \" /></span></div><!-- 验证码 --><input type=\"text\" name=\"page_name\" value=\"六一儿童节快乐之童年的游戏！\" style=\"display:none;\" /><input type=\"submit\" id=\"submit-cmt\" name=\"submit-cmt\" class=\"btn disabled\" value=\"发言\" disabled=\"disabled\" /></form><ul class=\"usr-cmt-list\" id=\"usr-cmt-list\"><h2 title=\"用户评论\" class=\"elements txt-hide title\">用户评论</h2><li class=\"clr\"><div class=\"avata\"><img src=\"/resource/comment_ico/cmt_ico10.png\" alt=\"\" /></div><p class=\"info\"><span class=\"usr-name\">ewrqrqwer</span>&nbsp;·&nbsp;<span class=\"launch-time\">2014/06/05 14:03</span></p><p class=\"cmt-content\">dsa</p></li><li class=\"clr\"><div class=\"avata\"><img src=\"/resource/comment_ico/cmt_ico6.png\" alt=\"\" /></div><p class=\"info\"><span class=\"usr-name\">ewrqrqwer</span>&nbsp;·&nbsp;<span class=\"launch-time\">2014/06/05 12:24</span></p><p class=\"cmt-content\">good</p></li><li class=\"clr\"><div class=\"avata\"><img src=\"/resource/comment_ico/cmt_ico5.png\" alt=\"\" /></div><p class=\"info\"><span class=\"usr-name\">ewrqrqwer</span>&nbsp;·&nbsp;<span class=\"launch-time\">2014/06/01 14:52</span></p><p class=\"cmt-content\">hustrewrs</p></li></ul><div class=\"page-index\"></div></div></div>', '1', '0', '1', '1', '1', '0', '0');
INSERT INTO `my_article` VALUES ('8', '62', '', '', '1406126456', '', '					', '0', '0', '1', '0', '0', '1', '0');
INSERT INTO `my_article` VALUES ('9', '64', '测试一下下线啊测试一下下线啊', '测试一下下线啊测试一下下线啊', '1406127341', '测试一下', '<div class=\"article\"><h1 class=\"article-title\">神马视频都拿下——硕鼠视频下载器</h1><p class=\"info\"><a href=\"http://weibo.com/u/3283500720/home?wvr=5&amp;lf=reg\" target=\"_blank\" class=\"author\">sunshine</a>&nbsp;·&nbsp;<span class=\"launch-time\">2014/07/04 06:35</span>&nbsp;·&nbsp;<span class=\"cmt-count\">2</span>条评论</p><p></p><p><span>如果有小伙伴喜欢在优酷搜狐爱奇艺这些网站上下视频的话，很可能碰到过这样的情况：喜欢的视频</span><span>分布在不同的网站上，需要分别注册各个网站的账号，而且还不一定能下载，这次给大家</span><span>介绍的硕鼠下载器就可以帮助大家解决这个问题，更好地下剧啦~</span> </p><p>也许已经有很多人知道硕鼠这个软件了，因为它确实是一个超棒的下载器，下载器的界面如下：</p><p><img src=\"/resource/kindeditor-4.1.7/attached/image/20140704/20140704051412_71557.jpg\" alt=\"\" /> </p><p>&nbsp;碰到你喜欢的软件想要下载时，只需要复制视频的链接到下载器的搜索框内，就可以进行下载啦，还可以选择下载不同清晰度的视频哦。硕鼠的下载范围囊括了优酷土豆、爱奇艺、搜狐、音悦台等国内主流的视频网站，同时硕鼠也有专门用于下载Youtube上视频的版本，<a href=\"http://app.hustonline.net/software/detail/361\" target=\"_blank\">点击这里下载</a> </p><p>&nbsp;文章相关软件为Windows版本，Mac版<a href=\"http://app.hustonline.net/software/detail/362\" target=\"_blank\">戳我下载</a> </p><p>&nbsp;&nbsp;功能强大、方便好用，碰到喜欢的视频不用郁闷不能下拉么么哒！</p><p><br /></p><p></p></div>', '0', '0', '1', '0', '0', '0', '0');

-- -----------------------------
-- Table structure for `my_category`
-- -----------------------------
DROP TABLE IF EXISTS `my_category`;
CREATE TABLE `my_category` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` char(15) NOT NULL DEFAULT '',
  `pid` int(10) unsigned NOT NULL DEFAULT '0',
  `sort` int(6) NOT NULL DEFAULT '100',
  `modelid` tinyint(1) NOT NULL DEFAULT '0',
  `isshow` tinyint(1) NOT NULL DEFAULT '1',
  `isverify` tinyint(1) NOT NULL DEFAULT '1',
  `ispush` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `pid` (`pid`)
) ENGINE=MyISAM AUTO_INCREMENT=66 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `my_category`
-- -----------------------------
INSERT INTO `my_category` VALUES ('62', '计算机专业', '0', '1', '0', '1', '1', '1');
INSERT INTO `my_category` VALUES ('63', '软件', '62', '100', '0', '1', '1', '0');
INSERT INTO `my_category` VALUES ('64', 'dsadsa', '63', '100', '0', '1', '1', '1');
INSERT INTO `my_category` VALUES ('65', 'ccxzx', '63', '100', '0', '0', '1', '0');

-- -----------------------------
-- Table structure for `my_comment`
-- -----------------------------
DROP TABLE IF EXISTS `my_comment`;
CREATE TABLE `my_comment` (
  `commend_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(10) unsigned NOT NULL,
  `aid` int(10) unsigned NOT NULL,
  `content` text NOT NULL,
  `islock` tinyint(1) unsigned NOT NULL,
  `pubtime` int(11) NOT NULL,
  PRIMARY KEY (`commend_id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `my_comment`
-- -----------------------------
INSERT INTO `my_comment` VALUES ('1', '1', '5', 'sd', '0', '1406094554');
INSERT INTO `my_comment` VALUES ('2', '1', '3', 'hahaha', '0', '1406162613');

-- -----------------------------
-- Table structure for `my_fields`
-- -----------------------------
DROP TABLE IF EXISTS `my_fields`;
CREATE TABLE `my_fields` (
  `fields_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `field` varchar(30) NOT NULL,
  `content` text NOT NULL,
  `issystem` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`fields_id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `my_fields`
-- -----------------------------
INSERT INTO `my_fields` VALUES ('1', 'title', '哈工大资源站', '1');
INSERT INTO `my_fields` VALUES ('2', 'description', '这是一个默认网站描述', '1');
INSERT INTO `my_fields` VALUES ('3', 'copyright', '工大资源网版权所有', '1');
INSERT INTO `my_fields` VALUES ('4', 'announcement', '这是站点公告哦', '1');
INSERT INTO `my_fields` VALUES ('5', 'ad', '这是一个首页广告', '1');

-- -----------------------------
-- Table structure for `my_link`
-- -----------------------------
DROP TABLE IF EXISTS `my_link`;
CREATE TABLE `my_link` (
  `link_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `url` varchar(255) NOT NULL,
  `isverify` tinyint(1) unsigned NOT NULL,
  PRIMARY KEY (`link_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `my_member_user`
-- -----------------------------
DROP TABLE IF EXISTS `my_member_user`;
CREATE TABLE `my_member_user` (
  `user_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(15) NOT NULL,
  `password` char(32) NOT NULL,
  `email` varchar(32) NOT NULL,
  `sex` tinyint(1) unsigned NOT NULL,
  `photo` char(100) NOT NULL,
  `regtime` int(10) unsigned NOT NULL DEFAULT '0',
  `regip` char(15) NOT NULL,
  `islock` tinyint(1) unsigned NOT NULL,
  `points` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `my_member_user`
-- -----------------------------
INSERT INTO `my_member_user` VALUES ('1', 'admin', '21232f297a57a5a743894a0e4a801fc3', '11111@sdsa.com', '1', '1406131128_1040281.jpg', '1405930522', '127.0.0.1', '0', '0');
INSERT INTO `my_member_user` VALUES ('11', 'gfgrsgs', '2ceeba3a00c180a8dafc3eebb8062407', 'gfgrsgs@qq.com', '1', 'sys/10.jpg', '1406161907', '127.0.0.1', '0', '0');
INSERT INTO `my_member_user` VALUES ('12', 'gfgrsgs2', '1290f18efab0fe4283d19ff86d8f49c2', 'gfgrsgs2@qq.com', '1', 'sys/8.jpg', '1406161932', '127.0.0.1', '0', '0');

-- -----------------------------
-- Table structure for `my_node`
-- -----------------------------
DROP TABLE IF EXISTS `my_node`;
CREATE TABLE `my_node` (
  `id` smallint(6) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL,
  `title` varchar(50) DEFAULT NULL,
  `status` tinyint(1) DEFAULT '0',
  `remark` varchar(255) DEFAULT NULL,
  `sort` smallint(6) unsigned DEFAULT NULL,
  `pid` smallint(6) unsigned NOT NULL,
  `level` tinyint(1) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `level` (`level`),
  KEY `pid` (`pid`),
  KEY `status` (`status`),
  KEY `name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `my_plugin`
-- -----------------------------
DROP TABLE IF EXISTS `my_plugin`;
CREATE TABLE `my_plugin` (
  `plugin_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(32) NOT NULL,
  `desc` varchar(255) NOT NULL DEFAULT '无',
  `method` varchar(255) NOT NULL,
  `isinstalled` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `position` tinyint(4) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`plugin_id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `my_plugin`
-- -----------------------------
INSERT INTO `my_plugin` VALUES ('7', 'Baidushare', '无', 'Index/Baidushare/info', '1', '0');

-- -----------------------------
-- Table structure for `my_role`
-- -----------------------------
DROP TABLE IF EXISTS `my_role`;
CREATE TABLE `my_role` (
  `id` smallint(6) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL,
  `pid` smallint(6) DEFAULT NULL,
  `status` tinyint(1) unsigned DEFAULT NULL,
  `remark` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `pid` (`pid`),
  KEY `status` (`status`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `my_role_user`
-- -----------------------------
DROP TABLE IF EXISTS `my_role_user`;
CREATE TABLE `my_role_user` (
  `role_id` mediumint(9) unsigned DEFAULT NULL,
  `user_id` char(32) DEFAULT NULL,
  KEY `group_id` (`role_id`),
  KEY `user_id` (`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `my_user`
-- -----------------------------
DROP TABLE IF EXISTS `my_user`;
CREATE TABLE `my_user` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `username` char(20) NOT NULL DEFAULT '',
  `password` char(32) NOT NULL DEFAULT '',
  `logintime` int(10) unsigned NOT NULL,
  `loginip` varchar(30) NOT NULL,
  `lock` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `my_user`
-- -----------------------------
INSERT INTO `my_user` VALUES ('6', 'sjp', '38dbcda0a1b1aad5d70827095605a2be', '1406162431', '127.0.0.1', '0');

-- -----------------------------
-- Table structure for `my_zan_ip`
-- -----------------------------
DROP TABLE IF EXISTS `my_zan_ip`;
CREATE TABLE `my_zan_ip` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `articleid` int(10) unsigned NOT NULL,
  `ip` varchar(30) CHARACTER SET utf8 NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  UNIQUE KEY `id_2` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

